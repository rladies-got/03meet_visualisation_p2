# Copyright 2020 -- QoG Data | Natalia Alvarado <natalia.alvarado@gu.se>
# Intended license: BSD 2-clause
# https://opensource.org/licenses/BSD-2-Clause

# QoG online seminar
# Introduction to graphs in R - Part II

# In the first part, we made scatterplots using base and ggplot
# In this section we will continue only with ggplot and learn how to
# create other types of graphs and to make them pretty!


# In this session:
# 3. Other types of graphs
# 4. Make things pretty: ggthemes, Rcolorbewer and patchwork
# Optional: How to make a more complex line graph


# Let's recap on how to produce a ggplot graph

# Load packages (different from Stata, you must install once, but load every time)
library(ggplot2)
library(RColorBrewer)
library(patchwork)
library(ggthemes)
library(ggrepel)
library(countrycode)


# Load data
df <- read.csv("qog_bas_ts_jan20.csv")

# We did not save the data last time! We need to create again the data and 
# variable
 # Don't forget the comma!
df1 <- subset(df, year == 2014)
df1$newgdp <- log10(df1$wdi_gdpcapcon2010)


# Now to the plots!
ggplot(df1, aes(x = undp_hdi, y = newgdp)) +
  geom_point()


# Add a region variable using countrycode package! First check what code we need
?codelist


df1$region <- countrycode(df1$cname, origin = "country.name", destination = "continent", warn = TRUE) # it adds the region 
# according to name, the warning let's us know WHICH names it did not found a 
# correspondence to
df1$region[df1$cname == "Tibet"] <- "Asia"


# alternatively, you can also choose shape
p1 <- ggplot(data = df1, aes(x = undp_hdi, y = newgdp, color = region)) + 
  geom_point()
p1


ggplot(data = df1, aes(x = undp_hdi, y = newgdp, shape = region)) + 
  geom_point()


# If we just want to see how it would look like without saving we just
# run the code (again, difference between assigning and running)

ggplot(data = df1, aes(x = undp_hdi, y = newgdp, color = region)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y~x)



# There are colors stored under different names in R to check them at:
# http://www.stat.columbia.edu/~tzheng/files/Rcolor.pdf

p1 <- ggplot(data = df1, aes(x = undp_hdi, y = newgdp)) +
  geom_point(aes(color = region), size = 2) + # why is the aesthetics for 
  # color here and not up there with the rest?
  geom_smooth(method = "lm", formula = y~x, color = "dimgrey") # the key is to know HOW we want to color stuff.

p1



# Labels!
p1 <- p1 +
  labs(title = "Development and GDP",
       x = "HDI (0-1)",
       y = "Log of GDP",
       color = "Region")
p1



# Making it pretty without effort using integrated themes of ggplot2
# see examples at https://ggplot2.tidyverse.org/reference/ggtheme.html
p1 + theme_clean()


# The ggthemes has some known themes
p1 + theme_economist()


# It even has the STATA theme, for the nostalgic ones
p1 + theme_stata()


# Let's use a simple format (and assign it)
p1 <- p1 + theme_minimal()
p1



# What if we want to plot how countries behave at different levels of QoG?
# Facet_grid allows us to add conditions to our plots
p2 <- p1 + facet_grid(rows = vars(icrg_qog > 0.5)) +
  labs(title = "Development in countries with more and less QoG levels")
p2



# Let's focus in one region for now
df2 <- subset(df1, region == "Americas")


p3 <- ggplot(df2, aes(x = undp_hdi, y = newgdp)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y~x, color = "dimgrey") +
  theme_minimal() +
  labs(title = "Development and GDP in the Americas",
       x = "HDI (0-1)",
       y = "Log of GDP")
p3




# We label the countries
p3 + geom_text(aes(label = cname))


# Labels are messy, that's where ggrepel comes to the rescue
p3 <- p3 +
  geom_text_repel(aes(label = cname))

p3



# Let's focus on one country - line plots
# we can go back to the QoG Basic dataset we loaded and choose a country
df2 <- subset(df, cname == "Ecuador")



# We can also clean a bit the missing observations
df2 <- subset(df2, !(is.na(undp_hdi)))



# Now we plot, how do you imagine we can have a timeline that shows, per year, the HDI 
# in Ecuador?
p4 <- ggplot(df2, aes(x = year, y = undp_hdi)) +
  geom_line()


p4 # We see a dramatic increase in HDI like this. Let's modify the Y-axis so we can see 
# the whole range of values


p4 <- p4 + ylim(0, 1)
p4
# now the change seems less striking


# The limits of an axis is a very controversial topic, which is still debated. 
# For now let's eliminate a bit of blank space from the bottom

p4 <- p4 +
  ylim(0.4, 0.9)
p4 # some of the properties of a plot are overridden by new commands



# Let's add the values as labels
p4 <- p4 + 
  geom_text(aes(label = undp_hdi), size = 3, vjust = -1)
p4


# Let's make it pretty again
p4 <- p4 +
  geom_line(color = "#2c7bb6") + # We can use hex colours! https://htmlcolorcodes.com/ #2c7bb6
  labs(title = "Ecuador",
       x = "Year",
       y = "HDI") +
  theme_minimal()
  
p4




# Let's see what we have done
p1
p2
p3
p4





# Changing the colors with ColorBrewer
# ColorBrewer is a superuseful guide about colors
# colorbrewer.org

p1 <- p1 + 
  scale_colour_brewer(palette = "Dark2")
p1


p3 <- p3 +
  geom_point(color = "#ce4646")
p3


p5 <- p5 + 
  theme_minimal()
p5



# If you are ready to save your graph, you can simply call the object you've created
ggsave("p1.png", p1) # it saves at a standard size
ggsave("p2.png", p2, width = 10, height = 7, units = "cm") # you can set your own size
ggsave("p3.svg", p3) # Best format for paper publication
ggsave("p4.pdf", p4) # You can save in PDF 



# We now have four graphs we would like to put together, we can save them one by one or
# we can put them on a grid - Patchwork does it for you
p1 + p2


# If you want to have two rows 
p6 <- (p3)/(p1 + p4)
p6


# Ggplot2 dirty trick, it depends on the size on your plot view!
p6


ggsave("more_plots.png", p6)


# There are mmore resources you can look for
# Visit https://ggplot2.tidyverse.org/ to see more
# and visit https://github.com/erikgahner/awesome-ggplot2
# to find other packages you can use while using ggplot2


# NOTE:
print("On April 22-24, Wolfgang Viechtbauer will be teaching Intro to R, if you are 
interested in participating, make sure you check this link 
https://github.com/wviechtb/course_oor")




# Extra part of this session

# How about many lines? 
# Again, repeating this code? Maybe we should have done this at the beginning! 
# Half of the work for graphs is data managing
df$region <- countrycode(df$cname, origin = "country.name", destination = "continent", 
                         warn = T)

df3 <- subset(df, region == "Americas")


p5 <- ggplot(df3, aes(x = year, y = undp_hdi, group = cname)) + # we group them by name
  geom_line()
p5


p5 <- p5 + xlim(c(1990, 2018)) # setting the limits, pretty much like we did before
p5


# Maybe colouring helps untangle them
ggplot(df3, aes(x = year, y = undp_hdi, color = cname)) + # we group them
  geom_line() +
  xlim(c(1990, 2018)) +
  labs(title = "Human Development Index in the Americas",
       x = "Year",
       y = "HDI")



# Unintelligible. This is when we can play with colors and labels to make graphs better
# Let's focus on Ecuador again
# first we want to identify the lines by color, we need a variable to do so
# We use R's version of an IF statement (rather when)

df3$color1 <- 0
df3$color1[df3$cname == "Ecuador"] <- 1


p5 <- ggplot(df3, aes(x = year, y = undp_hdi, group = cname)) + # we group them
  geom_path(aes(color = factor(color1)), size = 0.71) + # we change it to factor and size
  xlim(c(1990, 2018)) +
  labs(title = "Human Development Index in the Americas",
       x = "Year",
       y = "HDI") 
p5


# Chaning to HEX colors "0" = "#cbc1ae", "1" = "#7a2929"
p5 <- p5 + scale_colour_manual(values = c("0" = "#cbc1ae", "1" = "#7a2929"))
p5



# Better! but Ecuador seems a bit buried here.
# Ggplot can make several graphs and stack them on top of each other
# We plot first the other countries and THEN we add Ecuador

# We will use subset, a nicer way to partition data!
subset(df3, color1 == 1)


p5 <- ggplot(df3, aes(x = year, y = undp_hdi, group = cname, label = cname)) + # we group them
  
  geom_path(data = subset(df3, color1 == 0), aes(color = factor(color1)), size = 0.71, color =
              "#cbc1ae") +
  
  geom_path(data = subset(df3, color1 == 1), aes(color = factor(color1)), size = 0.8,
            color = "#7a2929") +
  
  xlim(c(1990, 2019)) +
  labs(title = "Human Development Index in the Americas",
       x = "Year",
       y = "HDI") 
p5



p5 <- p5 + geom_label_repel(data = subset(df3, year == 2017 & cname == "Ecuador"),
                            aes(label = cname), 
                            nudge_x = 5,
                            size = 4,
                            segment.color = "grey30")

p5 <- p5 + theme_minimal()

ggsave("p5.pdf", p5)